<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'sahlandata');
define('DB_USER', 'root');
define('DB_PASS', '');

// Application settings
define('APP_NAME', 'Sahlandata');
define('APP_URL', 'http://localhost');
define('CURRENCY', 'NGN');
define('CURRENCY_SYMBOL', '₦');

// Alrahuzdata API Settings
define('ALRAHUZDATA_API_URL', 'https://alrahuzdata.com.ng/api/');
define('ALRAHUZDATA_API_TOKEN', '0d1626193abbe1eb16915d3267670e950a16e0ac');

// Security settings
define('PIN_HASH_ALGO', PASSWORD_DEFAULT);
define('SESSION_TIMEOUT', 3600); // 1 hour

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection function using mysqli
function getDBConnection() {
    $connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($connection->connect_error) {
        throw new Exception("Database connection failed: " . $connection->connect_error);
    }
    
    $connection->set_charset("utf8mb4");
    return $connection;
}

// Function to make API calls to alrahuzdata
function makeAlrahuzdataAPICall($endpoint, $data = []) {
    $url = ALRAHUZDATA_API_URL . $endpoint;
    
    $postData = array_merge($data, [
        'token' => ALRAHUZDATA_API_TOKEN
    ]);
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
        'Accept: application/json'
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        throw new Exception("API Error: " . $error);
    }
    
    if ($httpCode !== 200) {
        throw new Exception("API returned HTTP code: " . $httpCode);
    }
    
    $decodedResponse = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("Invalid JSON response from API");
    }
    
    return $decodedResponse;
}
?>
