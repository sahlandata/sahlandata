-- Database schema for Sahlandata application with mysqli
-- Run this SQL to create the necessary tables

CREATE DATABASE IF NOT EXISTS sahlandata;
USE sahlandata;

-- Users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    pin VARCHAR(255) NOT NULL, -- Hashed PIN
    wallet_balance DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Data plans table
CREATE TABLE data_plans (
    id VARCHAR(50) PRIMARY KEY,
    network ENUM('MTN', 'GLO', 'AIRTEL', '9MOBILE') NOT NULL,
    type ENUM('SME', 'SME2', 'CORPORATE_GIFTING', 'GIFTING') NOT NULL,
    size VARCHAR(20) NOT NULL,
    validate VARCHAR(20) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transactions table
CREATE TABLE transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    transaction_id VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('DATA', 'AIRTIME', 'BILLS') NOT NULL,
    network VARCHAR(20) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    plan_id VARCHAR(50),
    amount DECIMAL(10,2) NOT NULL,
    status ENUM('PENDING', 'SUCCESS', 'FAILED') NOT NULL,
    reference VARCHAR(100),
    api_response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user_id (user_id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- Wallet transactions table
CREATE TABLE wallet_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    transaction_id VARCHAR(50) NOT NULL,
    type ENUM('CREDIT', 'DEBIT') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    balance_before DECIMAL(10,2) NOT NULL,
    balance_after DECIMAL(10,2) NOT NULL,
    description TEXT,
    reference VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user_id (user_id),
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_type (type),
    INDEX idx_created_at (created_at)
);

-- API logs table for debugging
CREATE TABLE api_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    endpoint VARCHAR(100) NOT NULL,
    request_data TEXT,
    response_data TEXT,
    http_code INT,
    execution_time DECIMAL(5,3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_endpoint (endpoint),
    INDEX idx_created_at (created_at)
);

-- Insert sample data plans
INSERT INTO data_plans (id, network, type, size, validate, price) VALUES
-- MTN Plans
('mtn_sme_500mb', 'MTN', 'SME', '500MB', '30 Days', 145.00),
('mtn_sme_1gb', 'MTN', 'SME', '1GB', '30 Days', 290.00),
('mtn_sme_2gb', 'MTN', 'SME', '2GB', '30 Days', 580.00),
('mtn_sme_3gb', 'MTN', 'SME', '3GB', '30 Days', 870.00),
('mtn_sme_5gb', 'MTN', 'SME', '5GB', '30 Days', 1450.00),

-- GLO Plans
('glo_sme_500mb', 'GLO', 'SME', '500MB', '30 Days', 135.00),
('glo_sme_1gb', 'GLO', 'SME', '1GB', '30 Days', 270.00),
('glo_sme_2gb', 'GLO', 'SME', '2GB', '30 Days', 540.00),
('glo_sme_3gb', 'GLO', 'SME', '3GB', '30 Days', 810.00),
('glo_sme_5gb', 'GLO', 'SME', '5GB', '30 Days', 1350.00),

-- AIRTEL Plans
('airtel_sme_300mb', 'AIRTEL', 'SME', '300MB', '2 Days', 120.00),
('airtel_sme_500mb', 'AIRTEL', 'SME', '500MB', '30 Days', 140.00),
('airtel_sme_1gb', 'AIRTEL', 'SME', '1GB', '30 Days', 280.00),
('airtel_sme_2gb', 'AIRTEL', 'SME', '2GB', '30 Days', 560.00),
('airtel_sme_5gb', 'AIRTEL', 'SME', '5GB', '30 Days', 1400.00),
('airtel_sme_10gb', 'AIRTEL', 'SME', '10GB', '30 Days', 2800.00);

-- Insert sample user (PIN: 1234)
INSERT INTO users (username, email, phone, pin, wallet_balance) VALUES
('demo_user', 'demo@sahlandata.com', '08012345678', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 5000.00);
