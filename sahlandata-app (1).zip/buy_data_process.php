<?php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Invalid JSON input');
    }
    
    // Validate required fields
    $requiredFields = ['network', 'phone', 'type', 'plan_id', 'pin', 'amount'];
    foreach ($requiredFields as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }
    
    $network = $input['network'];
    $phone = $input['phone'];
    $type = $input['type'];
    $planId = $input['plan_id'];
    $pin = $input['pin'];
    $amount = floatval($input['amount']);
    
    // Validate phone number
    if (!preg_match('/^[0-9]{11}$/', $phone)) {
        throw new Exception('Invalid phone number format');
    }
    
    // Validate PIN (should be 4 digits)
    if (!preg_match('/^[0-9]{4}$/', $pin)) {
        throw new Exception('Invalid PIN format');
    }
    
    // Get database connection
    $conn = getDBConnection();
    
    // Start transaction
    $conn->autocommit(false);
    
    try {
        // Get user information and verify PIN
        session_start();
        $userId = $_SESSION['user_id'] ?? 1; // Default to user ID 1 for demo
        
        $stmt = $conn->prepare("SELECT wallet_balance, pin FROM users WHERE id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception('User not found');
        }
        
        $user = $result->fetch_assoc();
        $currentBalance = floatval($user['wallet_balance']);
        $hashedPin = $user['pin'];
        
        // Verify PIN
        if (!password_verify($pin, $hashedPin)) {
            throw new Exception('Incorrect PIN. Please try again.');
        }
        
        // Check if user has sufficient balance
        if ($currentBalance < $amount) {
            throw new Exception('Insufficient wallet balance. Please fund your wallet.');
        }
        
        // Generate transaction ID
        $transactionId = 'DATA_' . strtoupper(uniqid());
        $transactionTime = date('Y-m-d H:i:s');
        
        // Get plan details
        $stmt = $conn->prepare("SELECT * FROM data_plans WHERE id = ?");
        $stmt->bind_param("s", $planId);
        $stmt->execute();
        $planResult = $stmt->get_result();
        $planDetails = $planResult->fetch_assoc();
        
        // Map network names for API
        $apiNetworkMap = [
            'MTN' => 'mtn',
            'GLO' => 'glo', 
            'AIRTEL' => 'airtel',
            '9MOBILE' => '9mobile'
        ];
        
        $apiNetwork = $apiNetworkMap[$network] ?? strtolower($network);
        
        // Make API call to alrahuzdata
        $apiData = [
            'network' => $apiNetwork,
            'phone' => $phone,
            'plan_id' => $planId,
            'amount' => $amount
        ];
        
        $apiResponse = makeAlrahuzdataAPICall('buy-data', $apiData);
        
        // Check API response
        if (isset($apiResponse['status']) && $apiResponse['status'] === 'success') {
            // API call successful - deduct amount from wallet
            $newBalance = $currentBalance - $amount;
            
            // Update user's wallet balance
            $stmt = $conn->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
            $stmt->bind_param("di", $newBalance, $userId);
            $stmt->execute();
            
            // Insert transaction record
            $status = 'SUCCESS';
            $reference = $apiResponse['reference'] ?? $apiResponse['transaction_id'] ?? $transactionId;
            $apiResponseJson = json_encode($apiResponse);
            
            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_id, type, network, phone, plan_id, amount, status, reference, api_response, created_at) VALUES (?, ?, 'DATA', ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssdssss", $userId, $transactionId, $network, $phone, $planId, $amount, $status, $reference, $apiResponseJson, $transactionTime);
            $stmt->execute();
            
            // Insert wallet transaction record
            $stmt = $conn->prepare("INSERT INTO wallet_transactions (user_id, transaction_id, type, amount, balance_before, balance_after, description, reference, created_at) VALUES (?, ?, 'DEBIT', ?, ?, ?, ?, ?, ?)");
            $description = "Data purchase - {$planDetails['size']} for {$phone}";
            $stmt->bind_param("isdddss", $userId, $transactionId, $amount, $currentBalance, $newBalance, $description, $reference);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            echo json_encode([
                'status' => 'success',
                'message' => $apiResponse['message'] ?? 'Data purchase successful',
                'transaction' => [
                    'transaction_id' => $transactionId,
                    'transaction_time' => $transactionTime,
                    'reference' => $reference,
                    'network' => $network,
                    'phone' => $phone,
                    'amount' => $amount,
                    'plan_id' => $planId,
                    'plan_size' => $planDetails['size'] ?? '',
                    'validity' => $planDetails['validate'] ?? ''
                ],
                'new_balance' => $newBalance,
                'api_response' => $apiResponse
            ]);
            
        } else {
            // API call failed
            $conn->rollback();
            
            $errorMessage = $apiResponse['message'] ?? 'Transaction failed. Please try again.';
            
            // Log failed transaction
            $status = 'FAILED';
            $apiResponseJson = json_encode($apiResponse);
            
            $stmt = $conn->prepare("INSERT INTO transactions (user_id, transaction_id, type, network, phone, plan_id, amount, status, api_response, created_at) VALUES (?, ?, 'DATA', ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssdss", $userId, $transactionId, $network, $phone, $planId, $amount, $status, $apiResponseJson, $transactionTime);
            $stmt->execute();
            
            echo json_encode([
                'status' => 'error',
                'message' => $errorMessage
            ]);
        }
        
    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }
    
    $conn->close();
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
