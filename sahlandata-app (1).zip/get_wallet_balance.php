<?php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // In a real application, you would:
    // 1. Authenticate the user (check session/token)
    // 2. Get user ID from session/token
    // 3. Query database for user's wallet balance
    
    // For demo purposes, we'll simulate getting user ID
    session_start();
    $userId = $_SESSION['user_id'] ?? 1; // Default to user ID 1 for demo
    
    // Get database connection
    $conn = getDBConnection();
    
    // Get user's wallet balance
    $stmt = $conn->prepare("SELECT wallet_balance FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $walletBalance = floatval($user['wallet_balance']);
    } else {
        // If user not found, create default user
        $stmt = $conn->prepare("INSERT INTO users (id, username, email, phone, pin, wallet_balance) VALUES (?, 'demo_user', 'demo@sahlandata.com', '08012345678', ?, 5000.00) ON DUPLICATE KEY UPDATE wallet_balance = wallet_balance");
        $hashedPin = password_hash('1234', PASSWORD_DEFAULT);
        $stmt->bind_param("is", $userId, $hashedPin);
        $stmt->execute();
        $walletBalance = 5000.00;
    }
    
    $conn->close();
    
    echo json_encode([
        'status' => 'success',
        'balance' => $walletBalance,
        'formatted_balance' => number_format($walletBalance, 2),
        'currency' => 'NGN'
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unable to fetch wallet balance: ' . $e->getMessage(),
        'balance' => 0
    ]);
}
?>
