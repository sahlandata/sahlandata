<?php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

try {
    // Get parameters
    $network = $_GET['network'] ?? '';
    $type = $_GET['type'] ?? '';
    
    // Validate parameters
    if (empty($network) || empty($type)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Network and type parameters are required'
        ]);
        exit;
    }
    
    // Get database connection
    $conn = getDBConnection();
    
    // First try to get plans from database
    $stmt = $conn->prepare("SELECT * FROM data_plans WHERE network = ? AND type = ? AND status = 'active' ORDER BY price ASC");
    $stmt->bind_param("ss", $network, $type);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $plans = [];
    while ($row = $result->fetch_assoc()) {
        $plans[] = [
            'id' => $row['id'],
            'size' => $row['size'],
            'validate' => $row['validate'],
            'price' => floatval($row['price'])
        ];
    }
    
    // If no plans in database, try to fetch from API and cache them
    if (empty($plans)) {
        try {
            // Map network names for API
            $apiNetworkMap = [
                'MTN' => 'mtn',
                'GLO' => 'glo',
                'AIRTEL' => 'airtel',
                '9MOBILE' => '9mobile'
            ];
            
            $apiNetwork = $apiNetworkMap[$network] ?? strtolower($network);
            
            // Fetch plans from alrahuzdata API
            $apiResponse = makeAlrahuzdataAPICall('data-plans', [
                'network' => $apiNetwork
            ]);
            
            if (isset($apiResponse['status']) && $apiResponse['status'] === 'success' && isset($apiResponse['data'])) {
                foreach ($apiResponse['data'] as $plan) {
                    // Filter by type if needed
                    $planType = $plan['type'] ?? 'SME';
                    if (strtoupper($planType) === $type) {
                        $plans[] = [
                            'id' => $plan['id'] ?? uniqid(),
                            'size' => $plan['size'] ?? $plan['plan'],
                            'validate' => $plan['validity'] ?? $plan['validate'] ?? '30 Days',
                            'price' => floatval($plan['price'] ?? $plan['amount'] ?? 0)
                        ];
                        
                        // Cache plan in database
                        $insertStmt = $conn->prepare("INSERT IGNORE INTO data_plans (id, network, type, size, validate, price) VALUES (?, ?, ?, ?, ?, ?)");
                        $planId = $plan['id'] ?? $network . '_' . $type . '_' . uniqid();
                        $insertStmt->bind_param("sssssd", $planId, $network, $type, $plan['size'], $plan['validity'], $plan['price']);
                        $insertStmt->execute();
                    }
                }
            }
        } catch (Exception $e) {
            // If API fails, use fallback plans
            error_log("API Error: " . $e->getMessage());
        }
    }
    
    // If still no plans, use fallback data
    if (empty($plans)) {
        $fallbackPlans = [
            'MTN' => [
                'SME' => [
                    ['id' => 'mtn_sme_500mb', 'size' => '500MB', 'validate' => '30 Days', 'price' => 145],
                    ['id' => 'mtn_sme_1gb', 'size' => '1GB', 'validate' => '30 Days', 'price' => 290],
                    ['id' => 'mtn_sme_2gb', 'size' => '2GB', 'validate' => '30 Days', 'price' => 580],
                    ['id' => 'mtn_sme_5gb', 'size' => '5GB', 'validate' => '30 Days', 'price' => 1450],
                ]
            ],
            'GLO' => [
                'SME' => [
                    ['id' => 'glo_sme_500mb', 'size' => '500MB', 'validate' => '30 Days', 'price' => 135],
                    ['id' => 'glo_sme_1gb', 'size' => '1GB', 'validate' => '30 Days', 'price' => 270],
                    ['id' => 'glo_sme_2gb', 'size' => '2GB', 'validate' => '30 Days', 'price' => 540],
                    ['id' => 'glo_sme_5gb', 'size' => '5GB', 'validate' => '30 Days', 'price' => 1350],
                ]
            ],
            'AIRTEL' => [
                'SME' => [
                    ['id' => 'airtel_sme_300mb', 'size' => '300MB', 'validate' => '2 Days', 'price' => 120],
                    ['id' => 'airtel_sme_500mb', 'size' => '500MB', 'validate' => '30 Days', 'price' => 140],
                    ['id' => 'airtel_sme_1gb', 'size' => '1GB', 'validate' => '30 Days', 'price' => 280],
                    ['id' => 'airtel_sme_2gb', 'size' => '2GB', 'validate' => '30 Days', 'price' => 560],
                    ['id' => 'airtel_sme_5gb', 'size' => '5GB', 'validate' => '30 Days', 'price' => 1400],
                ]
            ]
        ];
        
        $plans = $fallbackPlans[$network][$type] ?? [];
    }
    
    $conn->close();
    
    if (empty($plans)) {
        echo json_encode([
            'status' => 'error',
            'message' => 'No plans found for the selected network and type'
        ]);
        exit;
    }
    
    // Return success response
    echo json_encode([
        'status' => 'success',
        'plans' => $plans,
        'network' => $network,
        'type' => $type
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred while fetching plans: ' . $e->getMessage()
    ]);
}
?>
